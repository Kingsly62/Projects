# Caesar Cipher GUI

#### To run the program
python3 main.py

#### SetUps Imports

- import tkinter as tk

#### Difference Encription and Decryption

Encryption  processes of encoding the data. i.e converting plain text into ciphertext. This conversion is done with a key called an encryption key. Decryption: Decryption is a process of decoding the encoded data.


#### Instructions to The Project

- create a class name "CaesarCipher GUI" whereby will pass in the def_init_ for intilization .
- Caesar Cipher Technique is the simple and easy method of encryption technique. It is simple type of substitution cipher. Each letter of plain text is replaced by a letter with some fixed number of positions down with alphabet.


- Tkinter is the standard GUI library for Python. Python when combined with Tkinter provides a fast and easy way to create GUI applications. Tkinter provides a powerful object-oriented interface to the Tk GUI toolkit.

- The __init__ function is called every time an object is created from a class. The __init__ method lets the class initialize the object's attributes and serves no other purpose. It is only used within classes.

- The self keyword is used to represent an instance (object) of the given class.

- Ciphers, also called encryption algorithms, are systems for encrypting and decrypting data. A cipher converts the original message, called plaintext, into ciphertext using a key to determine how it is done.

-  Lambda Function in the project is an anonymous function or a function having no name.
It is a small and restricted function having no more than one line. 

- encrypt_callback and decrypt_callback is used because the code calls back a function at some time. ... encryption and authentication  Controlling a Drone with Python